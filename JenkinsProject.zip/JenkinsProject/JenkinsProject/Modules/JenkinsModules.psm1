#
# JenkinsModules.psm1
#
function Get-JenkinsCli {
	Param(
		[URI]$JenkinsURL,
		[String]$JenkinsCLIPath
	)
	if(!(Test-Path $JenkinsCLIPath)) {
		try {
			$WebClient = New-Object System.Net.WebClient
			Add-Content $LogFile -Value "Authenticating with Jenkins Server..."
			$WebClient.Credentials = New-Object System.Net.Networkcredential("Sivapavan", "password")
			Add-Content $LogFile -Value "[SUCCESS]::Successfully loged into Jenkins Server"
			$WebClient.DownloadFile("$JenkinsURL/jnlpJars/jenkins-cli.jar",$JenkinsCLIPath) 
			Add-Content $LogFile -Value "[SUCCESS]::Jenkins-Cli.jar downloaded at $JenkinsCLIPath"
			return 1
		}
		catch [Exception] {
			Add-Content $LogFile -Value "[FAILED]::Downloading Jenkins-Cli.jar from $JenkinsURL/jnlpJars/jenkins-cli.jar to $JenkinsCLIPath failed."
			Add-Content $LogFile -value $_.Exception.Message
			return -1
		}
	}
	else {
		Add-Content $LogFile -Value "$JenkinsCLIPath already downloaded."
		return 0
	}
}

function Get-Job {
	Param(
		[URI]$JenkinsURL,
		[String]$JenkinsCLIPath,
		[String]$JobName
	)
	[String]$getJobResult = java -jar $JenkinsCLIPath -s $JenkinsURL get-job $JobName
	if(!([string]::IsNullOrEmpty($getJobResult))) {
		return 1
	}
	else {
		return 0
	}
}
function Create-Job {
	Param(
		[URI]$JenkinsURL,
		[String]$JenkinsCLIPath,
		[String]$JobName,
		[String]$ConfigXMLPath
	)
	[int]$getJob = Get-Job -JenkinsURL $JenkinsURL -JenkinsCLIPath $JenkinsCLIPath -JobName $JobName
	if(!$getJob) {
		if(Test-Path $ConfigXMLPath) {
			[String]$createJobScript = "java -jar $JenkinsCLIPath -s $JenkinsURL create-job $JobName < $ConfigXMLPath"
			try {
				Add-Content $LogFile -Value "[CMD]::Executing $createJobScript"
				CMD '/C' $createJobScript
				return 0
			}
			catch [Exception] {
				[String]$logString = $_.Exception.Message
				Add-Content $LogFile -Value "[FAILED]:: Creating $JobName job failed."
				Add-Content $LogFile -Value $logString
				return -1
			}
		}
	}
	else {
		Add-Content $LogFile -Value "[FAILED]:: Creating $JobName job failed."
		Add-Content $LogFile -Value "[ERROR]::$JobName Already exists... "
		return -1
	}
}

function Build-Job {
	Param(
		[URI]$JenkinsURL,
		[String]$JenkinsCLIPath,
		[String]$JobName
	)
	[String]$buildJobScript = "java -jar $JenkinsCLIPath -s $JenkinsURL build $JobName"
	CMD /C $buildJobScript
	try {
		Add-Content $LogFile -Value "[CMD]:: Executing $buildJobScript"
		CMD /C $buildJobScript
		Add-Content $LogFile -Value "[SUCCESS]:: $JobName job builded successfully."
		return 0
	}
	catch [Exception] {
		[String]$logString = $_.Exception.Message
		Add-Content $LogFile -Value "[FAILED]:: Building $JobName job failed."
		Add-Content $LogFile -Value $logString
		return -1
	}
}

