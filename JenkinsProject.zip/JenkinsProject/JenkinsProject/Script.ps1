﻿#
# Script.ps1
#
Import-Module "$PSScriptRoot\Modules\JenkinsModules.psm1" -Force
$global:LogFile = "$PSScriptRoot\Logs\JenkinsLog.txt"

[xml]$configData = Get-Content "$PSScriptRoot/Configs/launcherconfig.xml"
[URI]$jenkinsURL = $configData.project.jenkins.url
[String]$jenkinsCLIPath = $PSScriptRoot + $configData.project.jenkins.cli
[String]$jobConfigPath = $PSScriptRoot + $configData.project.jenkins.xml
[String]$jobName = $configData.project.general.jobname
[int]$downloadCLI =  Get-JenkinsCli -JenkinsURL $jenkinsURL -JenkinsCLIPath $jenkinsCLIPath

if($downloadCLI -ne -1) {
	[int]$createJob = Create-Job -JenkinsURL $jenkinsURL -JenkinsCLIPath $jenkinsCLIPath -JobName $jobName -ConfigXMLPath $jobConfigPath

	if($createJob -ne -1) {
		[String]$JenkinsJobPath = "C:\Program Files (x86)\Jenkins\jobs\$jobName"
		while(!(Test-Path $JenkinsJobPath)) {
			Add-Content $LogFile -Value "Waiting to complete create-Job process..."
			Start-Sleep -Seconds 2
			Add-Content $LogFile -Value "[SUCCESS]:: $JobName job created."
		}
		Add-Content $LogFile -Value "[SUCCESS]:: $JobName job created."
		[int]$buildJob = Build-Job -JenkinsURL $jenkinsURL -JenkinsCLIPath $JenkinsCLIPath -JobName $jobName
	} 
}
else {
	return 0
}
